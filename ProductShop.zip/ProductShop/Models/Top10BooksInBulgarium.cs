﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace ProductShop.Models
{
    public partial class Top10BooksInBulgarium
    {
        public int? Rank { get; set; }
        [Column("BookID")]
        public int? BookId { get; set; }
        [StringLength(255)]
        [Unicode(false)]
        public string? Title { get; set; }
        [StringLength(255)]
        [Unicode(false)]
        public string? Author { get; set; }
        public int? PublicationYear { get; set; }
        [StringLength(255)]
        [Unicode(false)]
        public string? Genre { get; set; }
        [StringLength(255)]
        [Unicode(false)]
        public string? Publisher { get; set; }
        [StringLength(50)]
        [Unicode(false)]
        public string? Language { get; set; }
        public int? Pages { get; set; }
        [StringLength(50)]
        [Unicode(false)]
        public string? Format { get; set; }
        [StringLength(50)]
        [Unicode(false)]
        public string? Edition { get; set; }
        [StringLength(50)]
        [Unicode(false)]
        public string? Country { get; set; }
        [Column(TypeName = "decimal(10, 2)")]
        public decimal? Price { get; set; }
        [Column(TypeName = "decimal(3, 1)")]
        public decimal? Rating { get; set; }
        [Key]
        public int Id { get; set; }
    }
}
