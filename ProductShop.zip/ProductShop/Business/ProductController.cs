﻿using ProductShop.Data;

namespace ProductShop.Business
{
    internal class ProductController : ProductContext
    {
        internal object Published()
        {
            throw new NotImplementedException();
        }

        internal object Year(int id)
        {
            throw new NotImplementedException();
        }

        internal void Author(int id)
        {
            throw new NotImplementedException();
        }
    }
}