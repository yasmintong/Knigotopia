﻿using ProductShop.Data;
using ProductShop.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductShop.Business
{
    public class ProductControlers
    {
        private ProductContext context;
         public ProductControlers()
         {
            this.context = new ProductController();

         }
        public List<Product> Published() => context.Products.ToList();
        public Product Get(int id)
        {
            var product = this.context.Products.FirstOrDefault(x => x.Id == id);

            return product;
        }
        public void Year( Product product)
        {
            this.context.Products.Add(product);
            this.context.SaveChanges();
        }
        public void Author(int id,Product product)
        {
            var productItem = this.Get(id);

            context.Products.Attach(productItem);
            this.context.Entry(productItem).CurrentValues.SetValues(product);
            this.context.SaveChanges();
        }

        public void  Genre (int id)
        {
            var productItem = this.Get(id);
            this.context.Products.Remove(productItem);
            this.context.SaveChanges();
        }
    }
}
