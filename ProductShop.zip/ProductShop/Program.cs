﻿using ProductShop.Data.Models;
using ProductShop.View;
using System;

namespace ProductShop
{
    class Program
    {
        static void Main(string[] args)
        {
            var display = new Display();

        }   
    }
}