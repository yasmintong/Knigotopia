﻿using ProductShop.Business;
using ProductShop.Data.Models;

namespace ProductShop.View
{
    internal class ProducController
    {
        public static implicit operator ProducController(ProductController v)
        {
            throw new NotImplementedException();
        }

        internal void  Year(Product prod)
        {
            throw new NotImplementedException();
        }

        internal object Published()
        {
            throw new NotImplementedException();
        }

        internal void Author(int id)
        {
            throw new NotImplementedException();
        }
    }
}