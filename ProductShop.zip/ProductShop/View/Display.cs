﻿using System;
using ProductShop.Business;
using ProductShop.Data.Models;

namespace ProductShop.View
{
    public class Display
    {
        public Display()
        {
            controller = new ProductController();
            Input();
        }
        private  ProductController controller;
        private  int Close = 6;

        private void ShowAuthor()
        {

            Console.BackgroundColor = ConsoleColor.Cyan;
            Console.Clear();

            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine(new string('-', 46));
            Console.WriteLine(new string('*', 15) + "Library's TOP 3" + new string('*', 16));
            Console.WriteLine(new string('-', 46));
            Console.WriteLine("1. Title");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("2. Genre");
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine("3. Pages");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("4. Format");
            Console.ForegroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine("5. Rating");
            Console.ForegroundColor = ConsoleColor.DarkBlue;
            Console.WriteLine("6. Price");
            Console.ResetColor();

            

        }
        private void Input()
        {
            var operation = -1;
            do
            {
                ShowAuthor();
                string input = Console.ReadLine();

                if (!int.TryParse(input, out operation))
                {
                    Console.WriteLine("Invalid input. Please enter a valid number.");
                    continue;
                }

                switch (operation)
                {
                    case 1:
                        ListTitle();
                        break;
                    case 2:
                        Genre();
                        break;
                    case 3:
                        Pages();
                        break;
                    case 4:
                        Format();
                        break;
                    case 5:
                        Rating();
                        break;
                    default:
                        break;
                }
            } while (operation != Close);
        }
        private void ListTitle()
        {


            string title = Console.ReadLine();
            Console.WriteLine("Do you want to enter any author? (да/не)");
            string excludeResponse = Console.ReadLine();

            if (excludeResponse.ToLower() == "да")
            {
                Console.WriteLine("Enter the name of author you want to enter:Харпър Лий,Дъглас Адамс,Майкъл Краятън");
                string excludedAuthorsInput = Console.ReadLine();
                if (excludedAuthorsInput.Contains("Харпър Лий"))
                {
                    Console.WriteLine("Title: Да убиеш пресмехулник");
                }
                else
                {
                    Console.WriteLine("You did not choose to enter the author Харпър Лий.");
                }


                if (excludedAuthorsInput.Contains("Дъглас Адамс"))
                {
                    Console.WriteLine("Title:Автостопът към галактиката ");
                }
                else
                {
                    Console.WriteLine("You did not choose to enter the author Дъглас Адамс.");
                }



                if (excludedAuthorsInput.Contains("Майкъл Краятън"))
                {
                    Console.WriteLine("Title: Изгубеният свят");
                }
                else
                {
                    Console.WriteLine("You did not choose to enter the author Майкъл Краятън.");
                }
            }
            else
            {
                Console.WriteLine("You did not choose to exclude the author.");
            }
        }


        private void Rating()
        {
            string title = Console.ReadLine();
            Console.WriteLine("Do you want to enter any rating? (да/не)");
            string excludeResponse = Console.ReadLine();
            if (excludeResponse.ToLower() == "да")
            {
                Console.WriteLine("Enter the value of rating you want to :4.5,4.8,4.2");
                string excludedAuthorsInput = Console.ReadLine();
                if (excludedAuthorsInput.Contains("4.5"))
                {
                    Console.WriteLine("Title: Да убиеш пресмехулник,Харпър Лий");

                }
                else
                {
                    Console.WriteLine("You did not choose to enter the rating 4.5.");
                }


                if (excludedAuthorsInput.Contains("4.8"))
                {
                    Console.WriteLine("Title:Автостопът към галактиката,Дъглас Адамс ");
                }
                else
                {
                    Console.WriteLine("You did not choose to enter the rating 4.8.");
                }



                if (excludedAuthorsInput.Contains("4.2"))
                {
                    Console.WriteLine("Title: Изгубеният свят,Майкъл Краятън");
                }
                else
                {
                    Console.WriteLine("You did not choose to enter the rating 4.2.");
                }
            }
            else
            {
                Console.WriteLine("You did not choose to enter the rating.");
            }


        }

        private void Genre()
        {
            string title = Console.ReadLine();
            Console.WriteLine("Do you want to enter any genre? (да/не)");
            string excludeResponse = Console.ReadLine();
            if (excludeResponse.ToLower() == "да")
            {
                Console.WriteLine("Enter the name of genre you want to :роман,фантастика,научна фантастика");
                string excludedAuthorsInput = Console.ReadLine();
                if (excludedAuthorsInput.Contains("роман"))
                {
                    Console.WriteLine("Title: Да убиеш пресмехулник,Харпър Лий");

                }
                else
                {
                    Console.WriteLine("You did not choose to enter the genre роман.");
                }


                if (excludedAuthorsInput.Contains("фантастика"))
                {
                    Console.WriteLine("Title:Автостопът към галактиката,Дъглас Адамс ");
                }
                else
                {
                    Console.WriteLine("You did not choose to enter the genre фантастика.");
                }



                if (excludedAuthorsInput.Contains("научна фантастика"))
                {
                    Console.WriteLine("Title: Изгубеният свят,Майкъл Краятън");
                }
                else
                {
                    Console.WriteLine("You did not choose to enter the genre научна фантастика");
                }
            }
            else
            {
                Console.WriteLine("You did not choose to enter the genre.");
            }
        }

        private void Pages()
        {
            string title = Console.ReadLine();
            Console.WriteLine("Do you want to enter any page? (да/не)");
            string excludeResponse = Console.ReadLine();
            if (excludeResponse.ToLower() == "да")
            {
                Console.WriteLine("Enter the value of page you want to :336,224,500");
                string excludedAuthorsInput = Console.ReadLine();
                if (excludedAuthorsInput.Contains("336"))
                {
                    Console.WriteLine("Title: Да убиеш пресмехулник,Харпър Лий");

                }
                else
                {
                    Console.WriteLine("You did not choose to enter the page 336.");
                }


                if (excludedAuthorsInput.Contains("224"))
                {
                    Console.WriteLine("Title:Автостопът към галактиката,Дъглас Адамс ");
                }
                else
                {
                    Console.WriteLine("You did not choose to enter the page 224.");
                }



                if (excludedAuthorsInput.Contains("500"))
                {
                    Console.WriteLine("Title: Изгубеният свят,Майкъл Краятън");
                }
                else
                {
                    Console.WriteLine("You did not choose to enter the page 500");
                }
            }
            else
            {
                Console.WriteLine("You did not choose to enter the page.");
            }

        }

        private void Format()
        {

            string title = Console.ReadLine();
            Console.WriteLine("Do you want to enter any format? (да/не)");
            string excludeResponse = Console.ReadLine();
            if (excludeResponse.ToLower() == "да")
            {
                Console.WriteLine("Enter the name of format you want to :Мека корица1,Мека корица2,Твърда корица");
                string excludedAuthorsInput = Console.ReadLine();
                if (excludedAuthorsInput.Contains("мека корица1"))
                {
                    Console.WriteLine("Title: Да убиеш пресмехулник,Харпър Лий");

                }
                else
                {
                    Console.WriteLine("You did not choose to enter the format Мека корица1.");
                }


                if (excludedAuthorsInput.Contains("Мека корица2"))
                {
                    Console.WriteLine("Title:Автостопът към галактиката,Дъглас Адамс ");
                }
                else
                {
                    Console.WriteLine("You did not choose to enter the format Мека корица2.");
                }



                if (excludedAuthorsInput.Contains("Твърда корица"))
                {
                    Console.WriteLine("Title: Изгубеният свят,Майкъл Краятън");
                }
                else
                {
                    Console.WriteLine("You did not choose to enter the format Твърда корица");
                }
            }
            else
            {
                Console.WriteLine("You did not choose to enter the format.");
            }
        }
       
        
    }
}



