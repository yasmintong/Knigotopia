﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ProductShop.Migrations.TopBooksDb
{
    public partial class ProductShop : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Table,Books",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false),
                    Title = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true),
                    Author = table.Column<string>(type: "nchar(100)", fixedLength: true, maxLength: 100, nullable: true),
                    Year = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                });

            migrationBuilder.CreateTable(
                name: "Top10BooksInBulgaria",
                columns: table => new
                {
                    Rank = table.Column<int>(type: "int", nullable: true),
                    BookID = table.Column<int>(type: "int", nullable: true),
                    Title = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: true),
                    Author = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: true),
                    PublicationYear = table.Column<int>(type: "int", nullable: true),
                    Genre = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: true),
                    Publisher = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: true),
                    Language = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: true),
                    Pages = table.Column<int>(type: "int", nullable: true),
                    Format = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: true),
                    Edition = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: true),
                    Country = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: true),
                    Price = table.Column<decimal>(type: "decimal(10,2)", nullable: true),
                    Rating = table.Column<decimal>(type: "decimal(3,1)", nullable: true)
                },
                constraints: table =>
                {
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Table,Books");

            migrationBuilder.DropTable(
                name: "Top10BooksInBulgaria");
        }
    }
}
