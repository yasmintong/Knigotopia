﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductShop.Data
{
    public static class Configuration
    {
        public const string ConnectionString = "Server=.\\SQLEXPRESS;Database=Product;Integrated Security = True";
    }
}
