﻿CREATE DATABASE TopBooks;
USE TopBooks;
CREATE TABLE Top10BooksInBulgaria (
    Rank INT,
    BookID INT,
    Title VARCHAR(255),
    Author VARCHAR(255),
    PublicationYear INT,
    Genre VARCHAR(255),
    Publisher VARCHAR(255),
    Language VARCHAR(50),
    Pages INT,
    Format VARCHAR(50),
    Edition VARCHAR(50),
    Country VARCHAR(50),
    Price DECIMAL(10, 2),
    Rating DECIMAL(3, 1)
);
INSERT INTO Top10BooksInBulgaria (Rank, Title, Author, PublicationYear, Genre, Publisher, Language, Pages, Format, Edition, Country, Price, Rating)
VALUES 
    (1, 'Crossroad Fates', 'Haralan Alexandrov', 2020, 'Historical novel', 'Colibri', 'Bulgarian', 408, 'Hardcover', 'First Edition', 'Bulgaria', 18.90, 4.8),
    (2, 'Apocalypse. Sofia', 'Ivan Yankov', 2017, 'Science Fiction', 'Colibri', 'Bulgarian', 452, 'Hardcover', 'First Edition', 'Bulgaria', 15.00, 4.7),
    (3, 'To Cross a Border', 'Ivanka Hadzhieva', 2020, 'Novel', 'Bard', 'Bulgarian', 296, 'Hardcover', 'First Edition', 'Bulgaria', 12.00, 4.5),
    (4, 'A Monumental Grief', 'Milena Mikhal''kova', 2020, 'Novel', 'Colibri', 'Bulgarian', 256, 'Hardcover', 'First Edition', 'Bulgaria', 13.90, 4.7),
    (5, 'Machine', 'Martin Karbovski', 2020, 'Science Fiction', 'Colibri', 'Bulgarian', 448, 'Hardcover', 'First Edition', 'Bulgaria', 17.00, 4.8),
    (6, 'The Fate of the Unforgettable', 'Mariana Tsvetkova', 2020, 'Historical novel', 'Bard', 'Bulgarian', 384, 'Hardcover', 'First Edition', 'Bulgaria', 16.50, 4.7),
    (7, 'To the Sun', 'Mariana Tsvetkova', 2018, 'Historical novel', 'Bard', 'Bulgarian', 320, 'Hardcover', 'First Edition', 'Bulgaria', 16.50, 4.6),
    (8, 'The Congress of the Lovers', 'Archo Artsev', 2020, 'Novel', 'Janet 45', 'Bulgarian', 192, 'Hardcover', 'First Edition', 'Bulgaria', 12.00, 4.5),
    (9, 'Turning Points', 'Grisha Ganchev', 2020, 'Poetry', 'Art Media Group', 'Bulgarian', 124, 'Softcover', 'First Edition', 'Bulgaria', 12.00, 4.6),
    (10, 'Psycho-E', 'Mikhail Milanov', 2019, 'Science Fiction', 'Bard', 'Bulgarian', 368, 'Hardcover', 'First Edition', 'Bulgaria', 14.90, 4.8)
	;
	CREATE TABLE Library (
    BookID INT PRIMARY KEY,
    Title NVARCHAR(100),
    Author NVARCHAR(100),
    PublicationYear INT,
    Genre NVARCHAR(50),
    Publisher NVARCHAR(100),
    Language NVARCHAR(50),
    Pages INT,
    Format NVARCHAR(50),
    Edition NVARCHAR(50),
    Country NVARCHAR(50),
    Price DECIMAL(10,2),
    Rating DECIMAL(3,1)
);
INSERT INTO Library (BookID, Title, Author, PublicationYear, Genre, Publisher, Language, Pages, Format, Edition, Country, Price, Rating)
VALUES 
    (1, 'To Kill a Mockingbird', 'Harper Lee', 1960, 'Novel', 'J. B. Lippincott & Co.', 'English', 336, 'Softcover', 'First Edition', 'USA', 10.99, 4.5),
    (2, '1984', 'George Orwell', 1949, 'Dystopia', 'Secker & Warburg', 'English', 328, 'Hardcover', 'First Edition', 'UK', 9.99, 4.7),
    (3, 'The Great Gatsby', 'F. Scott Fitzgerald', 1925, 'Novel', 'Charles Scribner''s Sons', 'English', 180, 'Softcover', 'First Edition', 'USA', 8.50, 4.3),
    (4, 'Jurassic Park', 'Michael Crichton', 1990, 'Science Fiction', 'Random House', 'English', 500, 'Hardcover', 'Fourth Edition', 'USA', 15.99, 4.2),
    (5, 'The Hitchhiker''s Guide to the Galaxy', 'Douglas Adams', 1979, 'Science Fiction', 'Pan Books', 'English', 224, 'Softcover', 'Fifth Edition', 'UK', 12.50, 4.8),
    (6, 'Momo', 'Michael Ende', 1973, 'Children''s Fantasy', 'K. Thienemanns Verlag', 'German', 260, 'Hardcover', 'First Edition', 'Germany', 11.75, 4.6),
    (7, 'The Secret Garden', 'Frances Hodgson Burnett', 1911, 'Children''s Literature', 'Frederick Warne & Co.', 'English', 331, 'Softcover', 'First Edition', 'UK', 7.99, 4.4),
    (8, 'The Little Prince', 'Antoine de Saint-Exupéry', 1943, 'Fairy Tale', 'Reynal & Hitchcock', 'French', 96, 'Hardcover', 'First Edition', 'France', 9.25, 4.9),
    (9, 'Under the Sign of the Snake', 'Freddie Bartelme', 2005, 'Fantasy', 'Bard', 'Bulgarian', 360, 'Hardcover', 'Second Edition', 'Bulgaria', 14.99, 4.7),
    (10, 'King Diabolic', 'Douglas Niles', 1997, 'Fantasy', 'Orbit', 'English', 432, 'Softcover', 'Third Edition', 'USA', 13.50, 4.8),
    (11, 'Brian Boru: The King of Ireland', 'Morgan Lutenska', 2021, 'Historical Fiction', 'Art Media', 'Bulgarian', 280, 'Hardcover', 'First Edition', 'Bulgaria', 16.50, 4.6),
    (12, 'Azazel', 'Boris Akunin', 1998, 'Detective Novel', 'IK "Fut"', 'Russian', 320, 'Softcover', 'Second Edition', 'Russia', 11.00, 4.4),
    (13, 'Apocalypse', 'Stewart Jones', 2010, 'Post-Apocalyptic', 'Penguin Books', 'English', 400, 'Softcover', 'Fifth Edition', 'UK', 12.25, 4.5),
    (14, 'American Gods', 'Neil Gaiman', 2001, 'Fantasy', 'William Morrow', 'English', 635, 'Hardcover', 'Fourth Edition', 'USA', 18.99, 4.6),
    (15, 'Grimmer', 'Daniel Keyes', 2007, 'Horror', 'Doubleday', 'English', 318, 'Hardcover', 'Second Edition', 'USA', 11.50, 4.3);
