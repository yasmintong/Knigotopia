﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Library.Data;
using Library.Models;

namespace Library.Controllers
{
    public class Top10BooksInBulgariaController : Controller
    {
        private readonly TopBooksContext _context;

        public Top10BooksInBulgariaController(TopBooksContext context)
        {
            _context = context;
        }

        // GET: Top10BooksInBulgaria
        public async Task<IActionResult> Index()
        {
            


            return _context.Top10BooksInBulgaria != null ? 
                          View(await _context.Top10BooksInBulgaria.Skip(0).Take(5).ToListAsync()) :
                          Problem("Entity set 'TopBooksContext.Top10BooksInBulgaria'  is null.");
        }

        // GET: Top10BooksInBulgaria/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Top10BooksInBulgaria == null)
            {
                return NotFound();
            }

            var top10BooksInBulgaria = await _context.Top10BooksInBulgaria
                .FirstOrDefaultAsync(m => m.Id == id);
            if (top10BooksInBulgaria == null)
            {
                return NotFound();
            }

            return View(top10BooksInBulgaria);
        }

        // GET: Top10BooksInBulgaria/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Top10BooksInBulgaria/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Rank,BookId,Title,Author,PublicationYear,Genre,Publisher,Language,Pages,Format,Edition,Country,Price,Rating")] Top10BooksInBulgaria top10BooksInBulgaria)
        {
            if (ModelState.IsValid)
            {
                _context.Add(top10BooksInBulgaria);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(top10BooksInBulgaria);
        }

        // GET: Top10BooksInBulgaria/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Top10BooksInBulgaria == null)
            {
                return NotFound();
            }

            var top10BooksInBulgaria = await _context.Top10BooksInBulgaria.FindAsync(id);
            if (top10BooksInBulgaria == null)
            {
                return NotFound();
            }
            return View(top10BooksInBulgaria);
        }

        // POST: Top10BooksInBulgaria/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Rank,BookId,Title,Author,PublicationYear,Genre,Publisher,Language,Pages,Format,Edition,Country,Price,Rating")] Top10BooksInBulgaria top10BooksInBulgaria)
        {
            if (id != top10BooksInBulgaria.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(top10BooksInBulgaria);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!Top10BooksInBulgariaExists(top10BooksInBulgaria.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            string errors = string.Join(";", ModelState.Values.SelectMany(x => x.Errors).Select(x => x.ErrorMessage));



            ModelState.AddModelError("", errors);

            return View(top10BooksInBulgaria);
        }

        // GET: Top10BooksInBulgaria/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Top10BooksInBulgaria == null)
            {
                return NotFound();
            }

            var top10BooksInBulgaria = await _context.Top10BooksInBulgaria
                .FirstOrDefaultAsync(m => m.Id == id);
            if (top10BooksInBulgaria == null)
            {
                return NotFound();
            }

            return View(top10BooksInBulgaria);
        }

        // POST: Top10BooksInBulgaria/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Top10BooksInBulgaria == null)
            {
                return Problem("Entity set 'TopBooksContext.Top10BooksInBulgaria'  is null.");
            }
            var top10BooksInBulgaria = await _context.Top10BooksInBulgaria.FindAsync(id);
            if (top10BooksInBulgaria != null)
            {
                _context.Top10BooksInBulgaria.Remove(top10BooksInBulgaria);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool Top10BooksInBulgariaExists(int id)
        {
          return (_context.Top10BooksInBulgaria?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}
